//
//  ContentView.swift
//  SwiggyDashboard
//
//  Created by vivek bajirao deshmukh on 15/07/20.
//  Copyright © 2020 vivek bajirao deshmukh. All rights reserved.
//

import SwiftUI
import Combine

struct Box{
    var id: Int
    let title, imagurl : String
}

struct ContentView: View {
    
    let boxes : [Box] = [
        Box(id: 0, title: "Lazziz Foods", imagurl: "meat"),
        Box(id: 1, title: "Maju Foods", imagurl: "pizza"),
        Box(id: 2, title: "Aaziz Foods", imagurl: "meat"),
        Box(id: 3, title: "Baba Foods", imagurl: "pizza"),
        Box(id: 4, title: "Farhat Foods", imagurl: "meat"),
    ]
    
    let screenSize = UIScreen.main.bounds
    
    init() {
        // To remove all separators including the actual ones:
        UITableView.appearance().separatorStyle = .none
    }
    
    var body: some View {

        NavigationView{
            
            HStack(alignment: .center){
                
                List{
                    Image("meat")
                        .resizable()
                         .frame(width: 340, height: 140)
                        .cornerRadius(16)
                        .overlay(ImageOverlay(), alignment: .bottomTrailing)
                        .padding(20)
                        .shadow(color: Color.white, radius: 6.0, x: -8, y: -8)
                        .shadow(color: Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)), radius: 6.0, x: 8, y: 8)
                    Image("pizza")
                        .resizable()
                        .frame(width: 340, height: 140)
                        .cornerRadius(16)
                        .overlay(ImageLayer(), alignment: .bottomTrailing)
                        .padding(20)
                        .shadow(color: Color.white, radius: 6.0, x: -8, y: -8)
                        .shadow(color: Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)), radius: 6.0, x: 8, y: 8)
                    
                    
                    VStack{
                        Text("Top Picks For You")
                        .bold()
                        .font(.headline)
                    }
                    
                    
                    ScrollView(.horizontal, showsIndicators: false){
                        
                        HStack{
                            ForEach(0...4,id:\.self){ index in
                                Boxview(box: self.boxes[index])
                            }

                    }
                    }.frame(width: 400, height: 140)
                    
                    ScrollView(.horizontal, showsIndicators: false){
                        
                        HStack{
                            ForEach(0...4,id:\.self){ index in
                                ADboxview(box: self.boxes[index])
                            }

                         }
                    }
                    
                    VStack{
                        Text("In Spotlights")
                        .bold()
                        .font(.headline)
                    }
                    
                    ScrollView(.horizontal, showsIndicators: false){
                        
                        HStack{
                            ForEach(0...4,id:\.self){ index in
                                SpotlightBox(box: self.boxes[index])
                            }
                        }
                        
                    }.frame(width: 400, height: 140)
                    
                    
                    }
            
            .navigationBarTitle("Swiggy")

        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ImageOverlay: View {
    var body: some View {
        HStack(alignment: .center){
            ZStack {
                       Text("Non Veg")
                           .font(.callout)
                           .padding(6)
                           .foregroundColor(.white)
                   }.background(Color.black)
                   .opacity(0.8)
                   .cornerRadius(10.0)
                   .padding(6)
        }
        
       
    }
}


struct ImageLayer: View {
    var body: some View {
        HStack(alignment: .center){
            ZStack {
                       Text("Veg")
                           .font(.callout)
                           .padding(6)
                           .foregroundColor(.white)
                   }.background(Color.black)
                   .opacity(0.8)
                   .cornerRadius(10.0)
                   .padding(6)
        }

    }
}

struct Boxview: View {
    let box : Box
    
    var body: some View{
        VStack{
            Image("\(box.imagurl)")
                .resizable()
                .cornerRadius(16)
                .frame(width: 80, height: 80)
                .shadow(color: Color.white, radius: 6.0, x: -8, y: -8)
                .shadow(color: Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)), radius: 6.0, x: 8, y: 8)
            Text("\(box.title)")
                .font(.subheadline)
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)
                .lineLimit(2)
            Spacer()
        }
    }
}

}


struct ADboxview:View {

let box : Box

    var body: some View{
            VStack{
                Image("\(box.imagurl)")
                .resizable()
                .cornerRadius(16)
                .frame(width: 350, height: 200)
                .padding(10)
                .shadow(color: Color.white, radius: 6.0, x: -8, y: -8)
                .shadow(color: Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)), radius: 6.0, x: 8, y: 8)
            }
    }
    
}


struct SpotlightBox: View {
    let box : Box
      var body: some View{
        VStack{
            Image("\(box.imagurl)")
            .resizable()
            .cornerRadius(16)
            .frame(width: 80, height: 80)
            

        }
    }
    
}
